//
//  SampleApp.swift
//  Sample
//
//  Created by Aishwarya Prabhu on 18/09/23.
//

import SwiftUI

@main
struct SampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
