//
//  clickButtons.swift
//  Ovulio
//
//  Created by Aishwarya Prabhu on 27/09/23.
//

import UIKit

class clickButtons: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func checkButton0(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            
        
        }
        else{
            sender.isSelected = true
            
        }
    }
    
    @IBAction func checkButton2(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            
        
        }
        else{
            sender.isSelected = true
            
        }
    }
    @IBAction func checkButton1(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            
        
        }
        else{
            sender.isSelected = true
            
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
