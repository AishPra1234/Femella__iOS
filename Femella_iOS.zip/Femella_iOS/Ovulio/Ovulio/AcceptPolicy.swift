//
//  AcceptPolicy.swift
//  Ovulio
//
//  Created by Aishwarya Prabhu on 26/09/23.
//

import UIKit

class AcceptPolicy: UIViewController {

   
    @IBOutlet var continues: UIButton!
    
    var count = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        disableButton()

        // Do any additional setup after loading the view.
    }
    
    func disableButton(){
        continues.isEnabled = false
    }
    
    @IBAction func checkBox(_ sender: UIButton) {
        if sender.isSelected{
            sender.isSelected = false
            count = count - 1
            continues.isEnabled = false
        
        }
        else{
            sender.isSelected = true
            count = count + 1
        }
        if(count == 2){
            continues.isEnabled = true
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
