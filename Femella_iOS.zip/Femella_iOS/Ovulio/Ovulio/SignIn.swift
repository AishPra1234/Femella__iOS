//
//  SignIn.swift
//  Ovulio
//
//  Created by Aishwarya Prabhu on 25/09/23.
//

import UIKit

class SignIn: UIViewController {

    @IBOutlet weak var signinbutton: UIButton!
    
    

    @IBOutlet var alerts: UILabel!
    
    @IBOutlet var pass: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        alerts.isHidden = true
    }
    

    
    @IBAction func SignAction(_ sender: Any) {
        let passText = pass.text!
        print(passText)
        print("H")
        if(passText == "pass"){
            self.performSegue(withIdentifier: "acceptpolicy", sender: self)
        }
        else{
            alerts.isHidden = false
        }
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
